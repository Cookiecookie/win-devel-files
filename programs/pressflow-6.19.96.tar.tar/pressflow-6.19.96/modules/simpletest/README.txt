$Id: README.txt,v 1.12.4.4 2009/03/28 03:35:17 boombatower Exp $

AUTHOR
------
Jimmy Berry ("boombatower", http://drupal.org/user/214218)

PROJECT PAGE
------------
If you need more information, have an issue, or feature request please
visit the project page at: http://drupal.org/project/simpletest.

DESCRIPTION
-----------
SimpleTest 6.x-2.x is a backport of Drupal 7 core SimpleTest and has the same
requirements as Drupal 7 SimpleTest.

STATUS
------
Drupal 7 core SimpleTest developement is backported regularly. To find out when
the code was last backport check the CHANGELOG.txt or version release date.

ISSUES
------
If you encounter issues please try and confirm they are Drupal 6 specifc. This
module has only required changes made in order for it to function in Drupal 6.
Any issues that are related to the Drupal 6 backport may be posted to:
http://drupal.org/project/issues/simpletest, but any issues with API or general
concerns should be posted to the SimpleTest core issue queue:
http://tinyurl.com/simpletest-core.
