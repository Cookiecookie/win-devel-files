For a Solr JavaScript Client, see:
http://evolvingweb.github.com/ajax-solr/

For information on (now deprecated) SorlJS, see:
http://wiki.apache.org/solr/SolrJS
